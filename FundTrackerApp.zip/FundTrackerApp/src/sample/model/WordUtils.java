package sample.model;

/**
 * Class created by Sam
 */
public class WordUtils {
static String capitalize(String name) {
        return name.substring(0,1).toUpperCase()+name.substring(1);
        }
        }
